/******** CLOCK ********/
function updateClock() {
  const el = document.getElementById("clock");
  if (!el) return;
  el.innerText = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
setInterval(updateClock, 1000);
updateClock();

/******** NAVIGATION ********/
const screens = document.querySelectorAll(".tabScreen");

document.querySelectorAll("#bottomNav button").forEach(btn => {
  btn.addEventListener("click", () => {
    screens.forEach(s => s.classList.add("hidden"));
    const target = document.getElementById(btn.dataset.tab);
    if (target) target.classList.remove("hidden");
    if (btn.dataset.tab === "mapScreen") {
      setTimeout(() => { if (window.map) map.invalidateSize(); }, 200);
    }
  });
});

screens.forEach(s => s.classList.add("hidden"));
document.getElementById("homeScreen").classList.remove("hidden");

/******** USERS + PIN ********/
let users = []; // [{name, pin:null|string}]
let currentUser = null; // name

function loadUsers() {
  const stored = localStorage.getItem("vehicleUsers");
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length && typeof parsed[0] === "string") {
        users = parsed.map(n => ({ name: n, pin: null }));
      } else {
        users = parsed || [];
      }
    } catch {
      users = [];
    }
  } else {
    users = [];
  }
  currentUser = localStorage.getItem("vehicleCurrentUser");
  updateUserDisplay();
}
function saveUsers() {
  localStorage.setItem("vehicleUsers", JSON.stringify(users));
  if (currentUser) localStorage.setItem("vehicleCurrentUser", currentUser);
  else localStorage.removeItem("vehicleCurrentUser");
  updateUserDisplay();
}
function getCurrentUserObj() {
  return users.find(u => u.name === currentUser) || null;
}
function updateUserDisplay() {
  const homeUserEl = document.querySelector("#homeScreen p strong");
  if (homeUserEl) homeUserEl.textContent = currentUser || "Guest";
}
function setupUsers() {
  loadUsers();
  const addBtn = document.getElementById("addUserBtn");
  const switchBtn = document.getElementById("switchUserBtn");
  const deleteBtn = document.getElementById("deleteUserBtn");
  const setPinBtn = document.getElementById("setPinBtn");

  addBtn.addEventListener("click", () => {
    const name = prompt("Enter new user name:");
    if (!name) return;
    let u = users.find(x => x.name === name);
    if (!u) {
      u = { name, pin: null };
      users.push(u);
    }
    currentUser = name;
    saveUsers();
  });

  switchBtn.addEventListener("click", () => {
    if (users.length === 0) return alert("No users.");
    const name = prompt(`Users:\n${users.map(u => u.name).join(", ")}\n\nSwitch to:`);
    if (!name) return;
    if (users.find(u => u.name === name)) {
      currentUser = name;
      saveUsers();
    }
  });

  deleteBtn.addEventListener("click", () => {
    if (users.length === 0) return alert("No users.");
    const name = prompt(`Users:\n${users.map(u => u.name).join(", ")}\n\nDelete:`);
    if (!name) return;
    if (!users.find(u => u.name === name)) return;
    if (!confirm(`Delete '${name}'?`)) return;
    users = users.filter(u => u.name !== name);
    if (currentUser === name) currentUser = users[0]?.name || null;
    saveUsers();
  });

  setPinBtn.addEventListener("click", () => {
    if (!currentUser) return alert("Select a user first.");
    const u = getCurrentUserObj();
    const pin = prompt("Set PIN for this user (4–6 digits, blank to remove):", u.pin || "");
    if (pin === null) return;
    const trimmed = pin.trim();
    if (!trimmed) {
      u.pin = null;
      saveUsers();
      alert("PIN removed.");
      return;
    }
    if (!/^\d{4,6}$/.test(trimmed)) {
      alert("PIN must be 4–6 digits.");
      return;
    }
    u.pin = trimmed;
    saveUsers();
    alert("PIN set.");
  });
}

/******** LOCK SCREEN ********/
function setupLockScreen() {
  const lockScreen = document.getElementById("lockScreen");
  const pinInput = document.getElementById("pinInput");
  const pinMessage = document.getElementById("pinMessage");
  const keys = document.querySelectorAll(".pinKey");
  const clearBtn = document.getElementById("pinClear");
  const enterBtn = document.getElementById("pinEnter");

  function currentUserHasPin() {
    const u = getCurrentUserObj();
    return !!(u && u.pin);
  }

  function showLockedIfNeeded() {
    if (currentUserHasPin()) {
      lockScreen.style.display = "flex";
      pinInput.value = "";
      pinMessage.textContent = "";
    } else {
      lockScreen.style.display = "none";
    }
  }

  keys.forEach(k => {
    k.addEventListener("click", () => {
      if (pinInput.value.length < 6) pinInput.value += k.textContent;
    });
  });
  clearBtn.addEventListener("click", () => {
    pinInput.value = "";
  });
  enterBtn.addEventListener("click", () => {
    const u = getCurrentUserObj();
    if (!u || !u.pin) {
      lockScreen.style.display = "none";
      return;
    }
    if (pinInput.value === u.pin) {
      lockScreen.style.display = "none";
    } else {
      pinMessage.textContent = "Incorrect PIN";
    }
  });

  // Run once on load
  showLockedIfNeeded();

  // Also re-check when user changes
  window.addEventListener("storage", () => {
    loadUsers();
    showLockedIfNeeded();
  });
}

/******** MAP ********/
let map;
let marker;
let accuracyCircle;
let routeLine;
let autoFollow = true;
let lastCoords = null;
let lastHeading = 0;

const speedEl = () => document.getElementById("speedVal");
const altEl   = () => document.getElementById("altVal");
const headEl  = () => document.getElementById("headVal");

function createVehicleIcon() {
  return L.divIcon({
    className: "vehicle-icon",
    iconSize: [32, 32],
    iconAnchor: [16, 16]
  });
}
function setMarkerRotation(angleDeg) {
  lastHeading = angleDeg;
  if (marker && marker._icon) {
    marker._icon.style.transform =
      `translate(-50%, -50%) rotate(${angleDeg}deg)`;
  }
}
function computeHeading(from, to) {
  const toRad = d => d * Math.PI / 180;
  const toDeg = r => r * 180 / Math.PI;
  const lat1 = toRad(from[0]);
  const lat2 = toRad(to[0]);
  const dLon = toRad(to[1] - from[1]);
  const y = Math.sin(dLon) * Math.cos(lat2);
  const x = Math.cos(lat1) * Math.sin(lat2) -
            Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
  let brng = toDeg(Math.atan2(y, x));
  return (brng + 360) % 360;
}
function initMap() {
  const defaultLoc = [39.8283, -98.5795];
  map = L.map("map").setView(defaultLoc, 5);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(map);
  marker = L.marker(defaultLoc, { icon: createVehicleIcon() }).addTo(map);
  accuracyCircle = L.circle(defaultLoc, {
    radius: 0,
    color: "#1f4cff55",
    fillColor: "#1f4cff55",
    fillOpacity: 0.3
  }).addTo(map);
  routeLine = L.polyline([], { color: "cyan", weight: 3, opacity: 0.8 }).addTo(map);

  if (!navigator.geolocation) return;
  navigator.geolocation.watchPosition(
    pos => {
      const lat = pos.coords.latitude;
      const lon = pos.coords.longitude;
      const acc = pos.coords.accuracy;
      const speed = pos.coords.speed;
      const alt = pos.coords.altitude;
      const heading = pos.coords.heading;
      const newCoords = [lat, lon];

      routeLine.addLatLng(newCoords);

      let headingDeg = lastHeading;
      if (heading !== null && !isNaN(heading)) headingDeg = heading;
      else if (lastCoords) headingDeg = computeHeading(lastCoords, newCoords);

      lastCoords = newCoords;
      marker.setLatLng(newCoords);
      setMarkerRotation(headingDeg);
      accuracyCircle.setLatLng(newCoords);
      accuracyCircle.setRadius(acc);

      if (speedEl()) speedEl().textContent = speed ? (speed * 3.6).toFixed(1) : "0.0";
      if (altEl())   altEl().textContent   = alt ? alt.toFixed(1) : "0.0";
      if (headEl())  headEl().textContent  = headingDeg.toFixed(0);

      if (autoFollow) map.setView(newCoords, 16);
    },
    err => { console.warn("GPS unavailable:", err.message); },
    { enableHighAccuracy: true, maximumAge: 0, timeout: 5000 }
  );
  map.on("dragstart", () => autoFollow = false);
}
window.initMap = initMap;
function centerOnVehicle() { if (lastCoords && map) { autoFollow = true; map.setView(lastCoords, 16); } }
function zoomIn()  { if (map) map.zoomIn(); }
function zoomOut() { if (map) map.zoomOut(); }

/******** VOICE ********/
let recognition = null;
let listening = false;
let wakeWord = "vehicle";
function setupVoice() {
  const VoiceRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const voiceButtons = document.querySelectorAll("#voiceScreen button");
  const startBtn = voiceButtons[0];
  const stopBtn = voiceButtons[1];
  const wakeBtn = voiceButtons[2];
  const wakeLabel = document.getElementById("wakeWordLabel");
  if (!VoiceRecognition) return;

  recognition = new VoiceRecognition();
  recognition.lang = "en-US";
  recognition.continuous = true;
  recognition.onresult = (event) => {
    const text = event.results[event.results.length - 1][0].transcript.trim().toLowerCase();
    if (!text.includes(wakeWord.toLowerCase())) return;
    if (text.includes("map")) showScreen("mapScreen");
    if (text.includes("home")) showScreen("homeScreen");
    if (text.includes("bluetooth")) showScreen("bluetoothScreen");
    if (text.includes("settings")) showScreen("settingsScreen");
  };
  startBtn.addEventListener("click", () => {
    if (!listening) { recognition.start(); listening = true; }
  });
  stopBtn.addEventListener("click", () => {
    if (listening) { recognition.stop(); listening = false; }
  });
  wakeBtn.addEventListener("click", () => {
    const newWord = prompt("Enter new wake word:", wakeWord);
    if (!newWord) return;
    wakeWord = newWord.toLowerCase();
    wakeLabel.textContent = wakeWord;
  });
}
function showScreen(id) {
  screens.forEach(s => s.classList.add("hidden"));
  const target = document.getElementById(id);
  if (target) target.classList.remove("hidden");
  if (id === "mapScreen" && map) setTimeout(() => map.invalidateSize(), 200);
}

/******** SETTINGS ********/
function setupSettings() {
  const settingsButtons = document.querySelectorAll("#settingsScreen button");
  const themeBtn = settingsButtons[0];
  const infoBtn = settingsButtons[1];
  const resetBtn = settingsButtons[2];

  themeBtn.addEventListener("click", () => {
    const body = document.body;
    const dark = body.dataset.theme !== "light";
    if (dark) {
      body.style.background = "#f5f5f5";
      body.style.color = "#000";
      body.dataset.theme = "light";
    } else {
      body.style.background = "#0b0b0b";
      body.style.color = "#fff";
      body.dataset.theme = "dark";
    }
  });
  infoBtn.addEventListener("click", () => {
    alert(`System Info:\n\nUser Agent:\n${navigator.userAgent}\n\nViewport: ${window.innerWidth}x${window.innerHeight}`);
  });
  resetBtn.addEventListener("click", () => {
    if (!confirm("Factory reset?")) return;
    localStorage.clear();
    location.reload();
  });

  setupRadioSettings();
  setupHotspot();
}

/******** RADIO ********/
let radioState = {
  band: "FM",
  minFreq: 87.5,
  maxFreq: 108.0,
  step: 0.2,
  currentFreq: 99.9,
  stations: {},
  muted: false
};
let radioHardwarePort = null;
let radioHardwareWriter = null;

function loadRadioState() {
  const stored = localStorage.getItem("vehicleRadioState");
  if (stored) {
    try { radioState = { ...radioState, ...JSON.parse(stored) }; } catch {}
  }
}
function saveRadioState() {
  localStorage.setItem("vehicleRadioState", JSON.stringify(radioState));
}
function updateRadioUI() {
  const bandEl   = document.getElementById("radioBand");
  const freqEl   = document.getElementById("radioFreq");
  const srcEl    = document.getElementById("radioSourceLabel");
  const urlEl    = document.getElementById("radioUrlLabel");
  const audioEl  = document.getElementById("radioAudio");
  if (bandEl) bandEl.textContent = radioState.band;
  if (freqEl) freqEl.textContent = radioState.currentFreq.toFixed(1);
  const key = radioState.currentFreq.toFixed(1);
  const url = radioState.stations[key];
  if (url) {
    if (srcEl) srcEl.textContent = "Internet";
    if (urlEl) urlEl.textContent = url;
    if (audioEl && audioEl.src !== url) audioEl.src = url;
  } else {
    if (srcEl) srcEl.textContent = "Hardware / None";
    if (urlEl) urlEl.textContent = "N/A";
  }
}
async function sendRadioHardwareCommand(cmd) {
  if (!radioHardwareWriter) return;
  try {
    const data = new TextEncoder().encode(cmd + "\n");
    await radioHardwareWriter.write(data);
  } catch (e) { console.error("Radio hardware write failed:", e); }
}
function tuneRadio(freq) {
  if (freq < radioState.minFreq) freq = radioState.minFreq;
  if (freq > radioState.maxFreq) freq = radioState.maxFreq;
  radioState.currentFreq = parseFloat(freq.toFixed(1));
  saveRadioState();
  updateRadioUI();
  const cmd = `TUNE:${radioState.band}:${radioState.currentFreq.toFixed(1)}`;
  sendRadioHardwareCommand(cmd);
  const key = radioState.currentFreq.toFixed(1);
  const url = radioState.stations[key];
  const audioEl = document.getElementById("radioAudio");
  if (audioEl && url) {
    if (audioEl.src !== url) audioEl.src = url;
    audioEl.play().catch(console.error);
  }
}
function setupRadioHome() {
  loadRadioState();
  updateRadioUI();
  const seekDownBtn = document.getElementById("radioSeekDownBtn");
  const seekUpBtn   = document.getElementById("radioSeekUpBtn");
  const toggleBand  = document.getElementById("radioToggleBandBtn");
  const playBtn     = document.getElementById("radioPlayBtn");
  const stopBtn     = document.getElementById("radioStopBtn");
  const muteBtn     = document.getElementById("radioMuteBtn");
  const audioEl     = document.getElementById("radioAudio");

  if (seekDownBtn) seekDownBtn.addEventListener("click", () => tuneRadio(radioState.currentFreq - radioState.step));
  if (seekUpBtn)   seekUpBtn.addEventListener("click", () => tuneRadio(radioState.currentFreq + radioState.step));
  if (toggleBand)  toggleBand.addEventListener("click", () => {
    radioState.band = radioState.band === "FM" ? "AM" : "FM";
    saveRadioState();
    updateRadioUI();
    tuneRadio(radioState.currentFreq);
  });

  if (playBtn && audioEl) {
    playBtn.addEventListener("click", () => {
      const key = radioState.currentFreq.toFixed(1);
      const url = radioState.stations[key];
      if (url) {
        if (audioEl.src !== url) audioEl.src = url;
        audioEl.play().catch(err => console.error("Play failed:", err));
        document.getElementById("radioSourceLabel").textContent = "Internet";
        document.getElementById("radioUrlLabel").textContent = url;
      } else {
        tuneRadio(radioState.currentFreq);
      }
    });
  }
  if (stopBtn && audioEl) stopBtn.addEventListener("click", () => audioEl.pause());
  if (muteBtn && audioEl) {
    muteBtn.addEventListener("click", () => {
      radioState.muted = !radioState.muted;
      audioEl.muted = radioState.muted;
      muteBtn.textContent = radioState.muted ? "Unmute" : "Mute";
      saveRadioState();
    });
  }
  if (audioEl) {
    audioEl.addEventListener("loadedmetadata", updateNowPlayingFromRadio);
    audioEl.addEventListener("playing", updateNowPlayingFromRadio);
  }
  tuneRadio(radioState.currentFreq);
}
function renderStationList() {
  const listEl = document.getElementById("radioStationList");
  if (!listEl) return;
  listEl.innerHTML = "";
  const keys = Object.keys(radioState.stations).sort((a, b) => parseFloat(a) - parseFloat(b));
  if (keys.length === 0) { listEl.innerHTML = "<li>No stations added yet.</li>"; return; }
  keys.forEach(k => {
    const li = document.createElement("li");
    li.style.listStyle = "none";
    li.style.marginBottom = "4px";
    li.textContent = `${k} → ${radioState.stations[k]}`;
    listEl.appendChild(li);
  });
}
function setupRadioSettings() {
  const bandSel   = document.getElementById("radioBandSelect");
  const minFreqEl = document.getElementById("radioMinFreq");
  const maxFreqEl = document.getElementById("radioMaxFreq");
  const stepEl    = document.getElementById("radioStep");
  const saveBtn   = document.getElementById("saveRadioSettingsBtn");
  const stationNumberInput = document.getElementById("stationNumberInput");
  const stationUrlInput    = document.getElementById("stationUrlInput");
  const addStationBtn      = document.getElementById("addStationBtn");
  const connectHwBtn       = document.getElementById("connectRadioHardwareBtn");
  const hwStatusEl         = document.getElementById("radioHardwareStatus");

  loadRadioState();
  if (bandSel)   bandSel.value = radioState.band;
  if (minFreqEl) minFreqEl.value = radioState.minFreq;
  if (maxFreqEl) maxFreqEl.value = radioState.maxFreq;
  if (stepEl)    stepEl.value    = radioState.step;
  renderStationList();

  if (saveBtn) saveBtn.addEventListener("click", () => {
    radioState.band    = bandSel.value;
    radioState.minFreq = parseFloat(minFreqEl.value) || radioState.minFreq;
    radioState.maxFreq = parseFloat(maxFreqEl.value) || radioState.maxFreq;
    radioState.step    = parseFloat(stepEl.value)    || radioState.step;
    saveRadioState();
    tuneRadio(radioState.currentFreq);
    alert("Radio settings saved.");
  });

  if (addStationBtn) addStationBtn.addEventListener("click", () => {
    const num = (stationNumberInput.value || "").trim();
    const url = (stationUrlInput.value || "").trim();
    if (!num || !url) { alert("Enter station number and URL."); return; }
    const freq = parseFloat(num);
    if (isNaN(freq)) { alert("Station number must be numeric (e.g. 94.1)."); return; }
    const key = freq.toFixed(1);
    radioState.stations[key] = url;
    saveRadioState();
    renderStationList();
    alert(`Station ${key} saved.`);
  });

  if (connectHwBtn && hwStatusEl) {
    connectHwBtn.addEventListener("click", async () => {
      if (!("serial" in navigator)) { alert("Web Serial not supported in this browser."); return; }
      try {
        radioHardwarePort = await navigator.serial.requestPort();
        await radioHardwarePort.open({ baudRate: 115200 });
        radioHardwareWriter = radioHardwarePort.writable.getWriter();
        hwStatusEl.textContent = "Hardware connected";
        await sendRadioHardwareCommand("INIT");
        tuneRadio(radioState.currentFreq);
      } catch (e) {
        console.error("Radio hardware connect failed:", e);
        hwStatusEl.textContent = "Hardware connect failed";
      }
    });
  }
}
function updateNowPlayingFromRadio() {
  const audioEl = document.getElementById("radioAudio");
  const songTitleEl = document.getElementById("songTitle");
  const songArtistEl = document.getElementById("songArtist");
  if (!audioEl || !audioEl.src) {
    if (songTitleEl) songTitleEl.textContent = "None";
    if (songArtistEl) songArtistEl.textContent = "None";
    return;
  }
  try {
    const url = new URL(audioEl.src);
    const file = url.pathname.split("/").pop();
    const base = file.split(".").slice(0, -1).join(".");
    if (songTitleEl) songTitleEl.textContent = base || "Unknown";
    if (songArtistEl) songArtistEl.textContent = "Unknown";
  } catch {
    if (songTitleEl) songTitleEl.textContent = "Unknown";
    if (songArtistEl) songArtistEl.textContent = "Unknown";
  }
}

/******** BLUETOOTH + QR + WIFI QR ********/
let btDevice = null;
let btServer = null;
let knownDevices = [];
function renderDeviceList() {
  const listEl = document.getElementById("btDeviceList");
  if (!listEl) return;
  listEl.innerHTML = "";
  if (knownDevices.length === 0) { listEl.innerHTML = "<li>No devices yet. Tap Scan.</li>"; return; }
  knownDevices.forEach((dev, idx) => {
    const li = document.createElement("li");
    li.style.listStyle = "none";
    li.style.marginBottom = "4px";
    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "btDeviceChoice";
    radio.value = idx;
    if (idx === 0) radio.checked = true;
    const label = document.createElement("span");
    label.textContent = ` ${dev.name || "Unnamed"} (${dev.id.slice(0, 8)}…)`;
    li.appendChild(radio);
    li.appendChild(label);
    listEl.appendChild(li);
  });
}
function setBtStatus(text) {
  const el = document.getElementById("btStatus");
  if (el) el.textContent = text;
}
function setupBluetooth() {
  const scanBtn         = document.getElementById("scanBtn");
  const connectSelected = document.getElementById("connectSelectedBtn");
  const autoPairBtn     = document.getElementById("autoPairBtn");
  const disconnectBtn   = document.getElementById("disconnectBtn");
  if (!scanBtn || !connectSelected || !autoPairBtn || !disconnectBtn) return;

  scanBtn.addEventListener("click", async () => {
    if (!navigator.bluetooth) { alert("Web Bluetooth not supported."); return; }
    try {
      const device = await navigator.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: [] });
      if (!knownDevices.find(d => d.id === device.id)) knownDevices.push(device);
      btDevice = device;
      renderDeviceList();
      setBtStatus(`Selected: ${device.name || "Unnamed"}`);
    } catch (e) { console.error(e); }
  });

  connectSelected.addEventListener("click", async () => {
    const radios = document.querySelectorAll("input[name='btDeviceChoice']");
    let idx = -1;
    radios.forEach(r => { if (r.checked) idx = parseInt(r.value, 10); });
    if (idx < 0 || !knownDevices[idx]) { alert("Select a device first."); return; }
    const device = knownDevices[idx];
    try {
      btServer = await device.gatt.connect();
      btDevice = device;
      setBtStatus(`Connected to ${device.name || "Device"}`);
      document.getElementById("btIcon").textContent = ">ᛒ: On";
    } catch (e) {
      console.error(e);
      setBtStatus("Failed to connect.");
    }
  });

  autoPairBtn.addEventListener("click", async () => {
    if (!navigator.bluetooth) { alert("Web Bluetooth not supported."); return; }
    try {
      const device = await navigator.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: [] });
      const server = await device.gatt.connect();
      btDevice = device;
      btServer = server;
      if (!knownDevices.find(d => d.id === device.id)) knownDevices.push(device);
      renderDeviceList();
      setBtStatus(`Auto‑paired with ${device.name || "Device"}`);
      document.getElementById("btIcon").textContent = ">ᛒ: On";
    } catch (e) {
      console.error("Auto‑pair failed:", e);
      setBtStatus("Auto‑pair failed.");
    }
  });

  disconnectBtn.addEventListener("click", () => {
    if (btDevice && btDevice.gatt.connected) {
      btDevice.gatt.disconnect();
      setBtStatus("Disconnected.");
      document.getElementById("btIcon").textContent = ">ᛒ: Off";
    }
  });

  renderDeviceList();
  setBtStatus("No Bluetooth device connected");
}

const btQRContainer = document.getElementById("btQR");
const generateQRBtn = document.getElementById("generateQRBtn");
if (generateQRBtn && btQRContainer) {
  const qrBluetoothInfo = { namePrefix: "VehicleOS", serviceUuid: "battery_service" };
  generateQRBtn.addEventListener("click", () => {
    btQRContainer.innerHTML = "";
    new QRCode(btQRContainer, { text: JSON.stringify(qrBluetoothInfo), width: 180, height: 180 });
  });
}
async function connectFromQR(info) {
  try {
    const device = await navigator.bluetooth.requestDevice({
      filters: [{ namePrefix: info.namePrefix }],
      optionalServices: [info.serviceUuid]
    });
    const server = await device.gatt.connect();
    btDevice = device;
    btServer = server;
    if (!knownDevices.find(d => d.id === device.id)) { knownDevices.push(device); renderDeviceList(); }
    setBtStatus(`Connected via QR: ${device.name || "Device"}`);
    document.getElementById("btIcon").textContent = ">ᛒ: On";
    return server;
  } catch (err) { console.error("QR Bluetooth connect failed:", err); }
}
window.handleScannedQR = (jsonString) => {
  try { const info = JSON.parse(jsonString); connectFromQR(info); }
  catch (e) { console.error("Invalid QR JSON:", e); }
};

const wifiQRContainer   = document.getElementById("wifiQR");
const generateWifiQRBtn = document.getElementById("generateWifiQRBtn");
if (generateWifiQRBtn && wifiQRContainer) {
  generateWifiQRBtn.addEventListener("click", () => {
    const ssid = document.getElementById("wifiSsid").value.trim();
    const pass = document.getElementById("wifiPass").value.trim();
    if (!ssid) { alert("Enter SSID."); return; }
    const wifiString = `WIFI:T:WPA;S:${ssid};P:${pass};;`;
    wifiQRContainer.innerHTML = "";
    new QRCode(wifiQRContainer, { text: wifiString, width: 180, height: 180 });
  });
}

/****************************************************
 * HOTSPOT AUTO-ON (IMPROVED)
 ****************************************************/
function setupHotspot() {
  const ssidEl = document.getElementById("hotspotSsid");
  const passEl = document.getElementById("hotspotPass");
  const toggleBtn = document.getElementById("toggleHotspotBtn");
  const statusEl = document.getElementById("hotspotStatus");
  const qrEl = document.getElementById("hotspotQR");

  let hotspotOn = true; // always on at boot

  function renderHotspot() {
    const ssid = ssidEl.value.trim() || "VehicleOS-Hotspot";
    const pass = passEl.value.trim() || "password123";

    statusEl.textContent = `Hotspot: ${hotspotOn ? "On" : "Off"}`;
    toggleBtn.textContent = hotspotOn ? "Disable Hotspot" : "Enable Hotspot";

    qrEl.innerHTML = "";
    if (hotspotOn) {
      const wifiString = `WIFI:T:WPA;S:${ssid};P:${pass};;`;
      new QRCode(qrEl, { text: wifiString, width: 180, height: 180 });
    }

    localStorage.setItem("hotspotSSID", ssid);
    localStorage.setItem("hotspotPASS", pass);
    localStorage.setItem("hotspotON", hotspotOn ? "1" : "0");
  }

  // Load saved settings
  ssidEl.value = localStorage.getItem("hotspotSSID") || "VehicleOS-Hotspot";
  passEl.value = localStorage.getItem("hotspotPASS") || "password123";
  hotspotOn = localStorage.getItem("hotspotON") !== "0";

  toggleBtn.addEventListener("click", () => {
    hotspotOn = !hotspotOn;
    renderHotspot();
  });

  renderHotspot();
}

/******** WEATHER WIDGET (GPS + Open-Meteo) ********/
function setupWeather() {
  const locEl = document.getElementById("weatherLocation");
  const tempEl = document.getElementById("weatherTemp");
  const descEl = document.getElementById("weatherDesc");
  const btn = document.getElementById("refreshWeatherBtn");

  async function fetchWeather(lat, lon) {
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`;
      const res = await fetch(url);
      const data = await res.json();
      const cw = data.current_weather;
      tempEl.textContent = cw.temperature.toFixed(1);
      descEl.textContent = `Wind ${cw.windspeed} km/h, Code ${cw.weathercode}`;
    } catch (e) {
      console.error(e);
      tempEl.textContent = "--";
      descEl.textContent = "Error";
    }
  }

  function refresh() {
    if (!navigator.geolocation) {
      locEl.textContent = "No GPS";
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        locEl.textContent = `${lat.toFixed(3)}, ${lon.toFixed(3)}`;
        fetchWeather(lat, lon);
      },
      err => {
        console.warn(err);
        locEl.textContent = "GPS error";
      }
    );
  }

  btn.addEventListener("click", refresh);
  refresh();
}
/****************************************************
 * REAL PLAYLISTS (YOU PROVIDE MP3 FILES)
 ****************************************************/
const mediaPlaylistData = [
  {
    title: "Last Night",
    artist: "Morgan Wallen",
    album: "One Thing At A Time",
    src: "media/morgan_last_night.mp3",
    art: "media/morgan.jpg"
  },
  {
    title: "Wasted On You",
    artist: "Morgan Wallen",
    album: "Dangerous",
    src: "media/morgan_wasted_on_you.mp3",
    art: "media/morgan2.jpg"
  },
  {
    title: "Animal I Have Become",
    artist: "Three Days Grace",
    album: "One-X",
    src: "media/3dg_animal.mp3",
    art: "media/3dg.jpg"
  },
  {
    title: "Never Too Late",
    artist: "Three Days Grace",
    album: "One-X",
    src: "media/3dg_never_too_late.mp3",
    art: "media/3dg2.jpg"
  },
  {
    title: "Runaway",
    artist: "Camron Whitcomb",
    album: "Singles",
    src: "media/camron_runaway.mp3",
    art: "media/camron.jpg"
  }
];



/******** NOW PLAYING FROM MEDIA ********/
function updateNowPlayingFromMedia(track) {
  const songTitleEl = document.getElementById("songTitle");
  const songArtistEl = document.getElementById("songArtist");
  if (songTitleEl) songTitleEl.textContent = track.title;
  if (songArtistEl) songArtistEl.textContent = track.artist;
}

/****************************************************
 * HONEYCUTT SEARCH (GOOGLE-STYLE CLONE, FIXED)
 ****************************************************/
function setupHoneycuttSearch() {
  const searchInput = document.getElementById("searchInput");
  const searchBtn = document.getElementById("searchBtn");
  const searchPage = document.getElementById("searchPage");
  const resultsPage = document.getElementById("resultsPage");
  const readerPage = document.getElementById("readerPage");
  const resultsList = document.getElementById("resultsList");
  const readerContent = document.getElementById("readerContent");
  const backToSearch = document.getElementById("backToSearch");
  const backToResults = document.getElementById("backToResults");

  async function performSearch(query) {
    searchPage.classList.add("hidden");
    resultsPage.classList.remove("hidden");
    readerPage.classList.add("hidden");

    resultsList.innerHTML = "<p>Searching…</p>";

    try {
      // Brave Search HTML endpoint (public, no CORS block)
      const url = `https://search.brave.com/search?q=${encodeURIComponent(query)}&source=web`;
      const proxy = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;

      const res = await fetch(proxy);
      const html = await res.text();

      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");

      const results = [...doc.querySelectorAll(".snippet")].map(r => ({
        title: r.querySelector(".snippet-title")?.innerText || "No title",
        link: r.querySelector("a")?.href || "#",
        snippet: r.querySelector(".snippet-description")?.innerText || ""
      }));

      resultsList.innerHTML = "";

      results.forEach(r => {
        const div = document.createElement("div");
        div.className = "searchResult";
        div.innerHTML = `
          <p class="resultTitle">${r.title}</p>
          <p class="resultLink">${r.link}</p>
          <p class="resultSnippet">${r.snippet}</p>
        `;
        div.addEventListener("click", () => openReader(r.link));
        resultsList.appendChild(div);
      });

    } catch (err) {
      resultsList.innerHTML = "<p>Error loading results.</p>";
      console.error(err);
    }
  }

  async function openReader(url) {
    resultsPage.classList.add("hidden");
    readerPage.classList.remove("hidden");

    readerContent.innerHTML = "<p>Loading page…</p>";

    try {
      const proxy = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
      const res = await fetch(proxy);
      const html = await res.text();

      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");

      const article =
        doc.querySelector("article") ||
        doc.querySelector("main") ||
        doc.querySelector("body");

      readerContent.innerHTML = article.innerHTML;

    } catch (err) {
      readerContent.innerHTML = "<p>Unable to load page.</p>";
      console.error(err);
    }
  }

  searchBtn.addEventListener("click", () => {
    if (searchInput.value.trim()) performSearch(searchInput.value.trim());
  });

  searchInput.addEventListener("keydown", e => {
    if (e.key === "Enter" && searchInput.value.trim()) {
      performSearch(searchInput.value.trim());
    }
  });

  backToSearch.addEventListener("click", () => {
    searchPage.classList.remove("hidden");
    resultsPage.classList.add("hidden");
    readerPage.classList.add("hidden");
  });

  backToResults.addEventListener("click", () => {
    resultsPage.classList.remove("hidden");
    readerPage.classList.add("hidden");
  });
}

/******** OBD-II LIVE DATA (Web Serial, simple text protocol) ********/
let obdPort = null;
let obdReader = null;
let obdKeepReading = false;

async function connectObd() {
  const statusEl = document.getElementById("obdStatus");
  if (!("serial" in navigator)) {
    statusEl.textContent = "Web Serial not supported";
    return;
  }
  try {
    obdPort = await navigator.serial.requestPort();
    await obdPort.open({ baudRate: 115200 });
    statusEl.textContent = "Connected, reading…";
    obdKeepReading = true;
    readObdLoop();
  } catch (e) {
    console.error(e);
    statusEl.textContent = "OBD connect failed";
  }
}

async function readObdLoop() {
  const rpmEl = document.getElementById("obdRpm");
  const spdEl = document.getElementById("obdSpeed");
  const coolEl = document.getElementById("obdCoolant");
  const thrEl = document.getElementById("obdThrottle");
  const statusEl = document.getElementById("obdStatus");

  try {
    const reader = obdPort.readable.getReader();
    obdReader = reader;
    const decoder = new TextDecoder();
    let buffer = "";
    while (obdKeepReading) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let idx;
      while ((idx = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx + 1);
        // Expect lines like: RPM:1234,SPEED:45,COOLANT:90,THROTTLE:23
        if (!line) continue;
        const parts = line.split(",");
        const data = {};
        parts.forEach(p => {
          const [k, v] = p.split(":");
          if (k && v) data[k.trim().toUpperCase()] = v.trim();
        });
        if (data.RPM) rpmEl.textContent = data.RPM;
        if (data.SPEED) spdEl.textContent = data.SPEED;
        if (data.COOLANT) coolEl.textContent = data.COOLANT;
        if (data.THROTTLE) thrEl.textContent = data.THROTTLE;
      }
    }
    reader.releaseLock();
    statusEl.textContent = "OBD stopped";
  } catch (e) {
    console.error(e);
    statusEl.textContent = "OBD read error";
  }
}

function setupObd() {
  const connectBtn = document.getElementById("connectObdBtn");
  const refreshBtn = document.getElementById("refreshVehicleBtn");
  connectBtn.addEventListener("click", () => {
    if (!obdPort) connectObd();
    else {
      obdKeepReading = !obdKeepReading;
      if (obdKeepReading) {
        document.getElementById("obdStatus").textContent = "Resuming…";
        readObdLoop();
      } else {
        document.getElementById("obdStatus").textContent = "Paused";
      }
    }
  });
  refreshBtn.addEventListener("click", () => {
    // Could send a specific PID request here if your firmware supports it
    document.getElementById("obdStatus").textContent = "Refresh requested";
  });
}

/******** STARTUP ANIMATION ********/
function runStartupAnimation() {
  const overlay = document.getElementById("startupOverlay");
  if (!overlay) return;
  setTimeout(() => {
    overlay.style.transition = "opacity 0.6s ease-out";
    overlay.style.opacity = "0";
    setTimeout(() => overlay.style.display = "none", 600);
  }, 1800);
}
/****************************************************
 * SAFE + COMPLETE setupMediaPlayer()
 ****************************************************/
function setupMediaPlayer() {
  const audio = document.getElementById("mediaAudio");
  const art = document.getElementById("mediaArt");
  const artShadow = document.getElementById("mediaArtShadow");
  const titleEl = document.getElementById("mediaTitle");
  const artistEl = document.getElementById("mediaArtist");
  const albumEl = document.getElementById("mediaAlbum");
  const prevBtn = document.getElementById("mediaPrev");
  const playPauseBtn = document.getElementById("mediaPlayPause");
  const nextBtn = document.getElementById("mediaNext");
  const listEl = document.getElementById("mediaPlaylist");
  const progressBar = document.getElementById("mediaProgressBar");
  const progressFill = document.getElementById("mediaProgressFill");

  if (!audio || !art || !titleEl || !artistEl || !albumEl) {
    console.warn("Media Player elements missing — skipping setup.");
    return;
  }

  let index = 0;
  let playing = false;

  function loadTrack(i) {
    const track = mediaPlaylistData[i];
    index = i;

    audio.src = track.src;
    art.src = track.art;
    titleEl.textContent = track.title;
    artistEl.textContent = track.artist;
    albumEl.textContent = track.album;

    renderPlaylist();
  }

  function renderPlaylist() {
    listEl.innerHTML = "";
    mediaPlaylistData.forEach((t, i) => {
      const li = document.createElement("li");
      li.textContent = `${t.title} — ${t.artist}`;
      li.className = i === index ? "media-active" : "";
      li.addEventListener("click", () => {
        loadTrack(i);
        audio.play().catch(console.error);
        playing = true;
        playPauseBtn.textContent = "⏸";
        art.classList.add("media-playing");
        artShadow.classList.add("media-playing");
      });
      listEl.appendChild(li);
    });
  }

  prevBtn.addEventListener("click", () => {
    index = (index - 1 + mediaPlaylistData.length) % mediaPlaylistData.length;
    loadTrack(index);
    audio.play().catch(console.error);
    playing = true;
    playPauseBtn.textContent = "⏸";
  });

  nextBtn.addEventListener("click", () => {
    index = (index + 1) % mediaPlaylistData.length;
    loadTrack(index);
    audio.play().catch(console.error);
    playing = true;
    playPauseBtn.textContent = "⏸";
  });

  playPauseBtn.addEventListener("click", () => {
    if (!playing) {
      audio.play().catch(console.error);
      playing = true;
      playPauseBtn.textContent = "⏸";
      art.classList.add("media-playing");
      artShadow.classList.add("media-playing");
    } else {
      audio.pause();
      playing = false;
      playPauseBtn.textContent = "▶";
      art.classList.remove("media-playing");
      artShadow.classList.remove("media-playing");
    }
  });

  audio.addEventListener("timeupdate", () => {
    if (!audio.duration) return;
    const pct = (audio.currentTime / audio.duration) * 100;
    progressFill.style.width = pct + "%";
  });

  audio.addEventListener("ended", () => {
    index = (index + 1) % mediaPlaylistData.length;
    loadTrack(index);
    audio.play().catch(console.error);
  });

  progressBar.addEventListener("click", (e) => {
    const rect = progressBar.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    audio.currentTime = pct * audio.duration;
  });

  loadTrack(index);
}


/******** INIT ********/
document.addEventListener("DOMContentLoaded", () => {
  loadUsers();
  setupUsers();
  setupLockScreen();
  setupBluetooth();
  setupVoice();
  setupSettings();
  setupRadioHome();
  setupWeather();
  setupMediaPlayer();
  setupHoneycuttSearch();
  setupObd();

  if (document.getElementById("map")) initMap();
  runStartupAnimation();
});

